import {Outlet, useNavigate} from "react-router-dom";
import {Button} from "antd-mobile";
import React, {useContext, useEffect} from "react";
import {MsgContext} from "@/index";
import {useDispatch} from "react-redux";
import {getBillList} from "@/store/modules/billStore";
import {TabBar} from "antd-mobile";
import {AddCircleOutline, BillOutline, CalculatorOutline} from "antd-mobile-icons";
import './index.css'

// const Layout = () => {
//     const user = useContext(MsgContext);
//     const {contact: {email}} = user;
//     //storeを通して、テストデータを得る。
//     const dispatch = useDispatch()
//     useEffect(() =>{
//         dispatch(getBillList())
//     },[dispatch])
//     return (
//         <div>我是Layout, {email}
//             <Outlet/>
//             <br/>
//             {/*全局样式测试*/}
//             <Button color="primary">测试全局</Button>
//             {/* 局部样式测试*/}
//             <div className="puple">
//                 <Button color="primary">测试局部</Button>
//             </div>
//         </div>)
// }
const tabs = [
    {
        key: '/month',
        title: '月度帳票',
        icon: <BillOutline/>
    },
    {
        key: '/new',
        title: '記票',
        icon: <AddCircleOutline/>
    },
    {
        key: '/year',
        title: '年度帳票',
        icon: <CalculatorOutline/>
    }
]

const Layout = () => {
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(getBillList())
    }, [dispatch])

    //メニューのパス変換
    const navigate = useNavigate()
    const swithRoute = (path) => {
        console.log(path)
        navigate(path)
    }
    return (

        <div className="layout">
            <div className="container">
                <Outlet/>
            </div>

            <div className="footer">
                <TabBar onChange={swithRoute} className="tabbar">
                    {tabs.map(item => (
                        <TabBar.Item key={item.key} icon = {item.icon} title={item.title}/>
                    ))}
                </TabBar>
            </div>
        </div>

    )
}
export default Layout