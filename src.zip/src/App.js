import {createContext} from "react";
import Month from "@/pages/Month";
import Layout from "@/pages/Layout";
import {MsgContext} from "@/index";

//1.App.jsでは、createContext（）を使用して、データ伝送用のオブジェクトを作る。


function App() {

    return (

        <div className="App">
            {/*2.Appコンポーネントでは、Providerコンポーネントを使用して、データを伝送する。*/}
                this is app
        </div>
    );
}


export default App;
