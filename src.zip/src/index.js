import React, {createContext, useEffect} from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import {Outlet, RouterProvider} from "react-router-dom";
import sum from "@/test";
import router from "@/router";
import {Provider, useDispatch} from "react-redux";
//导入定制主题文件
import './theme.css'
import Store from "@/store";
import {BillOutline,CalculatorOutline,AddCircleOutline} from 'antd-mobile-icons'
import {getBillList} from "@/store/modules/billStore";
const MsgContext = createContext()

console.log(sum(1,2))
const root = ReactDOM.createRoot(document.getElementById('root'));
const user = {
    name: 'Alice',
    age: 25,
    contact: {
        email: 'alice@example.com',
        phone: '123456789'
    }
}

root.render(
  // <React.StrictMode>
    <Provider store={Store}>
    <MsgContext.Provider value={user}>
        <RouterProvider router={router}>
            <App />
        </RouterProvider>
    </MsgContext.Provider>
    </Provider>
  // </React.StrictMode>
);
export {MsgContext};

