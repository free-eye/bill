## 1.navigate('/acticle?id=1001&name=zhangsan')とuseSearchParams()
### navigate('/acticle?id=1001&name=zhangsan') 「？」以後の内容は、パラメータの内容で、複数の場合、「＆」で繋がる。
### useSearchParams()で、上記のパラメータの値をとることができ、一つの配列にストレージする。
```javaScript
const [params] = useSearchParams()
let id = params.get('id')
```

## 2.navigate('/acticle/1001/zhangsan')とuseParams()
### navigate('/acticle?id=1001&name=zhangsan') 「？」以後の内容は、パラメータの内容で、複数の場合、「＆」で繋がる。
### useSearchParams()で、上記のパラメータの値をとることができ、一つのオブジェクトにストレージする。
この方法でパラメータの項目をrouterファイルの「path」でセット要。
```javaScript
path: '/article/:id/:name' 
element:<Article />
```
```javaScript
const params = useParams()
let id = params.id
let name = params.name
```
## 3.props でデータの伝送
### 親コンポーネントの設定
```js
import React from 'react';
import ChildComponent from './ChildComponent';

const ParentComponent = () => {
  const user = {
    name: 'Alice',
    age: 25,
    contact: {
      email: 'alice@example.com',
      phone: '123456789'
    }
  };

  return <ChildComponent user={user} />;
};
```
### 子コンポーネントの受け取り
```js
import React from 'react';

const ChildComponent = ({ user }) => {
  const { contact: { email } } = user;

  return <div>Email: {email}</div>;
};

export default ChildComponent;

```
## 4.useCotext()を通して、複数コンポーネント間のデータ伝送
### index.jsでは、createContext（）を使用して、データ伝送用のオブジェクトを作って、輸出する。
![Alt text](image-12.png)

### 「RouterProvider」と共に使用の場合、パスの有効利用を図るため、index.jsでは、Providerコンポーネントを使用して、データを伝送する。
![Alt text](image-13.png)
### 適用されたコンポーネントでは、useContext()でデータを受け取って使用する。
![Alt text](image-14.png)

## 5.嵌套路由（セカンダリルーティング設定）
### routerファイル中の設置
![Alt text](image-1.png)
### layout（初期コンポーネント）には、セカンダリコンポーネントの輸出場所をセット
![Alt text](image-2.png)
### 默认二级路由（デフォルトセカンダリルーティング）のindex設定
![Alt text](image-3.png)
### 404ページ（コンポーネント）の設定
![Alt text](image-4.png)
### lazy関数を用いて動的ルーティングのロードを実現し、プロジェクトのオープン時間を最適化する。
![Alt text](image-49.png)

## 6.1 urlの変換（useNavigate())
![Alt text](image-20.png)

## 6.2 useRef() とuseEffect()の併用で、DOMノードへの直接アクセス。
```jsx
import React, { useRef, useEffect } from 'react';

function MyComponent() {
  // DOM要素への参照を格納するためにrefを作成
  const myInputRef = useRef(null);

  useEffect(() => {
    // コンポーネントがマウントされた後、refを使用してDOM要素にアクセス
    myInputRef.current.focus();
  }, []);

  return <input ref={myInputRef} type="text" />;
}
```
## 6.3レンダリング間の変更可能なデータの保持
useRefはコンポーネントのライフサイクル全体を通して不変のままデータを保持するために使用することができます。useState()とは異なり、refの値を変更してもコンポーネントの再レンダリングはトリガーされません。
```jsx
import React, { useRef, useEffect } from 'react';

function TimerComponent() {
  // 创建一个ref来存储计数器值
  const countRef = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      // 更新ref的current值，但不会触发重新渲染
      countRef.current += 1;
      console.log(`Timer tick: ${countRef.current}`);
    }, 1000);

    // 清除定时器
    return () => clearInterval(timer);
  }, []); // 空依赖数组表示effect仅在组件挂载时运行

  return (
    <div>
      <p>查看控制台以看到计数器增加。</p>
    </div>
  );
}

export default TimerComponent;
```

## 7.别名路径（エイリアスを使ったパス指定）
![Alt text](image-5.png)
### プロジェクトのルートディレクトリ（根目录）には、「craco.config.js」ファイルを作成し、設定。
・webpackの配置を広げる。
![Alt text](image-6.png)
### パッケージ中の起動命令を修正。
![Alt text](image-7.png)

## 8.パス内ファイルの自動提示
### プロジェクトのルートディレクトリ（根目录）には、「jsconfig.json」ファイルを作成し、設定。
![Alt text](image-8.png)

## 9.json-serverでデータMock
### プロジェクトのルートディレクトリ（根目录）には、「server/data.json」でデータを用意する。
![Alt text](image-9.png)
### パッケージ中jsonServerの起動命令を追加
![Alt text](image-10.png)

## 10.antD-mobile(ReactのUIコンポーネントライブラリ)
### プロジェクトのグローバル設定(:root:root)
![Alt text](image-11.png)
### 特定スタイルの設定
![Alt text](image-15.png)

## 11.RTK(Redux Toolkit)状態管理ツール
### srcフォルダには、STOREフォルダを作り、下にindex.jsとモジュールフォルダを作成し、モジュールフォルダには各自項目のSTOREを作る。それに、index.jsファイルには、モジュール内の各自storeを導入する。
**一つの例は、下記の通りとする。**
#### モジュールフォルダには、「billStore.js」を作り、関連内容を入力。
![Alt text](image-16.png)
#### storeフォルダのindex.jsには、上記billStoreをインポートする。
![Alt text](image-17.png)
#### プロジェクトのルートディレクトリ（根目录）内のindex.jsには、上記のstoreをインポート。
![Alt text](image-18.png)
#### 該当されたファイルには、上記のuseEffect()とuseDispatch()を通して、json.serverのAPIからデータを受け取る。
![Alt text](image-19.png)

## 12.useMemo()／データの二次処理　lodash：月単位の統計、日単位の統計
### 配列のfilter条件及びreduce(a,c)の計算統計
![Alt text](image-21.png)
![Alt text](image-22.png)
### 更に日単位の統計
・日単位データの統計
![Alt text](image-24.png)
・コンポーネント及び関数のインポート
![Alt text](image-25.png)
・日単位コンポーネント内のデータ展示
![Alt text](image-26.png)
### 日データのリスト展示
・日データリストの展示状態のセット
![Alt text](image-27.png)
・リスト展示スタイルのセット
![Alt text](image-28.png)
### 各項目アイコンの使用
・Iconコンポーネントの作成及びタイプの連動をセット
![Alt text](image-29.png)
・日データリストへのアイコン使用
![Alt text](image-30.png)

## 13.useEffect（副作用フック）の初期化セット
![Alt text](image-23.png)

## 14.Ant Designライブラリの使用
### フォーマ（FormItem）
#### FormItemのnameとrules
・nameは、DBの項目名と一致要。
・rulesは、配列で、複数のチェックルールをセット可。上から下まで一つずつ実行され、ルール違反すると、エラーメッセージを提示可。
![Alt text](image-31.png)
#### Formのロストフォーカス時の上記ルールチェック
・validateTrigger="onBlur"
![Alt text](image-32.png)
#### onFinish関数は、フォーマから提出されたデータを受け取ることができる。
  **onFinishは他の関数と違い、自動的にフォーマのデータを引数として提出されること**
  **他の関数は、引数をインポートするとき、「onClick={()=> navigate(`/publish?id=${data.id}`)}」の書き方となる**
![Alt text](image-33.png)

## 15.axiosツールで、リクエストの方法をカプセル化（封装）する。
### ルートドメイン（ベースURL、タイムアウト、インターセプターなどのセット）
![Alt text](image-34.png)
### tokenのセット及び永続化
・ローカルストレージ(localStorage)も保存して、tokenの永続化を図る。
![Alt text](image-35.png)

## 16.axiosリクエストインターセプターには、TOKENの追加により、ユーザー関連の操作時、各自の追加が不要。。
### インターセプターには[TOKEN]を追加する。
![Alt text](image-36.png)

### ルーティング時の権限コントロール
・特定のコンポーネントを使って、TOKENを持っていないと、Loginページに遷移する。
![Alt text](image-37.png)

### ルーティング設定中の使用
![Alt text](image-38.png)

### tokenの有効期限切れの処理
・ユーザーが長時間に操作していないし、規定の有効期間を超過すると、トークンが無効となる。
・無効なユーザーが、APIへリクエストすれば、バックエンドから「401」のステータスコードをフィードバックしする。
・フロントエンドは、そのステータスコードを監視することで、無効なtokenを消して、ログインページに遷移。
![Alt text](image-42.png)

### ユーザー情報も同様処理で、Reduxの中で保存し、コンポーネントではインポートして使用できる。
![Alt text](image-39.png)
![Alt text](image-40.png)
![Alt text](image-41.png)

## 16.Echartのインポート及びカプセル化（重複使用）
### 新しいコンポーネントを作って、Echartのカプセル化を図る。（カスタマイズの部分を関数に）
![Alt text](image-43.png)
### 重複使用の場合、各自の関数をセット。
![Alt text](image-44.png)

## 17．apiのカプセル化
### apisフォルダの中に、user関連のapi（url、GET/POST、関数など）を作成する。
![Alt text](image-45.png)
### store中のメソッドでは、上記のapiを使用して、ログイン、データ取得などをする。
![Alt text](image-46.png)
### article関連のapiを作成し、説明文書に合わせてセット。
![Alt text](image-47.png)
### store中のメソッドでは、上記のapiを使用して、ログイン、データ取得などをする。
![Alt text](image-48.png)

## 18.可視化ツール（source-map-explorer)により、プロジェクトパッケージ内の各部分のサイズを確認する。
### source-map-explorerのインストール
source-map-explorerが依頼された「react-quillリッチテキスト編集機能」は、Reactバージョン（18.2.0）の矛盾によりインストール不可となって、「npm i source-map-explorer --legacy-peer-deps」の命令でインストール。
### package.jaonファイルでは、関連命令を設定。
![Alt text](image-50.png)
