//统一中转工具模块函数，import工具后再导出
import {request} from "./request";
import {setToken,getToken,removeToken} from "@/utils/token";

export {
    request,
    setToken,
    getToken,
    removeToken
}