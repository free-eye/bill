//axiosのカプセル化
import axios from "axios";
import {getToken, removeToken} from "@/utils/token";
import router from "@/router";
//ルートドメイン（根域名）のセット
//タイムアウトの時間セット
const request = axios.create({
    baseURL:'http://geek.itheima.net/v1_0',
    timeout:5000
})
//リクエストインターセプター（请求拦截器）
//在请求发送之前拦截，插入一下自定义的设置
request.interceptors.request.use((config)=>{
    //config中注入token，1获取到token，2.按照后端的要求做拼接
    const token = getToken()
    if(token){
        config.headers.Authorization = `Bearer ${token}`
    }
    return config
},(error)=>{
    return Promise.reject(error)
})

//レスポンスインターセプター（响应拦截器）
//在响应返回到客户端之前做拦截，重点处理返回的数据
request.interceptors.response.use((response)=>{
    //2xx 范围内的状态码都会触发该函数
    //对响应数据做点什么
    return response.data
},(error)=>{
    //超出 2xx 范围内的状态码会触发该函数
    //对响应错误做点什么
    //监控401状态码 token失效
    console.dir(error)
    if(error.response.status === 401){
        removeToken()
        router.navigate('/login')
        window.location.reload()
    }
    return Promise.reject(error)
})
export {request}


