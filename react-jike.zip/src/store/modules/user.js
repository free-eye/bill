//用户相关的状态管理

import {createSlice} from "@reduxjs/toolkit";
import {removeToken, request} from "@/utils";
import {setToken as _setToken,getToken} from "@/utils";
import {getProfileAPI, loginAPI} from "@/apis/user";


const useStore = createSlice({
    name: "user",
    initialState: {
        token: getToken() || '',
        userInfo:{}
    },
    //同步修改方法
    reducers: {
        setToken(state, action) {
            //redux中保存，但伴随浏览器刷新后会恢复初始化
            state.token = action.payload
            _setToken(action.payload)
        },
        setUserInfo(state,action){
            state.userInfo = action.payload
        },
        clearUserInfo(state){
            state.token = ''
            state.userInfo = {}
            removeToken()
        }
    }
})

//解构actionCreater
const {clearUserInfo,setToken,setUserInfo} = useStore.actions

//获得reducer函数
const useReducer = useStore.reducer

//异步方法 完成登录并获取token
const fetchLogin = (loginForm) => {
    return async (dispatch) => {
        //1.发送异步请求
        const res = await loginAPI(loginForm)
        //2.提交同步action进行token的存入
        dispatch(setToken(res.data.token))
    }
}
//异步方法 获取个人用户信息
const fetchUserInfo = ()=>{
    return async (dispatch) => {
        const res = await getProfileAPI()
        dispatch(setUserInfo(res.data))
    }
}

export {fetchLogin,fetchUserInfo, setToken,clearUserInfo}

export default useReducer