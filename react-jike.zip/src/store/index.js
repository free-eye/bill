//组合redux子模块，到处store实例

import {configureStore} from "@reduxjs/toolkit";
import userReducer from "@/store/modules/user";

export default  configureStore({
    reducer:{
        //用户子模块
        user:userReducer
    }
})