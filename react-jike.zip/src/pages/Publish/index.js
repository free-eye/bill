import {
    Card,
    Breadcrumb,
    Form,
    Button,
    Radio,
    Input,
    Upload,
    Space,
    Select, message
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import {Link, useSearchParams} from 'react-router-dom'
import './index.scss'
import ReactQuill from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import {useEffect, useState} from "react";
import {createArticleAPI, getArticleById, getChannelAPI, updateArticleAPI} from "@/apis/article";
import {useChannel} from "@/hooks/useChannel";

const { Option } = Select

const Publish = () => {
    //获取频道列表
    const {channelList} = useChannel()

    //提交表单
    const onFinish = (formValue)=>{
        console.log(formValue)
        console.log(imageList)
        //校验封面类型imageType是否与图面列表的数量是否一致
        if(imageList.length !==imageType)return message.warning('封面类型与图片数量不匹配')
        //1.按照接口文档的格式处理收集到的表单数据
        const {title,content,channel_id} = formValue
        const reqData ={
            title,
            content,
            cover:{
                type:imageType,//封面模式
                //这里要区分新增或者编辑两种状态处理URL
                images:imageList.map(item =>{
                    if(item.response){
                        //新增
                        return item.response.data.url
                    }else{
                        //编辑
                        return item.url
                    }
                    })//图片列表
            },
            channel_id
        }
        //2.调用接口提交（区分新增和更新）
        if(articleId){
            //更新
            updateArticleAPI({...reqData,id:articleId})
        }else {
            //新增
            createArticleAPI(reqData)
        }

        message.success('发布文章成功！')
    }

    //上传回调
    const [imageList,setImageList] = useState([])
    const onChange = (value)=>{
        console.log('正在上传中',value)
        setImageList(value.fileList)
    }
    const beforeUpload = (value) => {
        // value.fileList只表示当前上传文件的数量，要使用list的数量
        if (imageList.length >= imageType) {
            message.error(`最多只能上传${imageType}张图片`);
            return false;
        }
        return true;
    };

    //切换图片封面类型，上传组件的显示控制
    const [imageType,setImageType]= useState(1)
    const onTypeChange = (e)=>{
        setImageType(e.target.value)
    }

    //回填数据
    //获取选择的查询参数 文章id
    const [searchParams] = useSearchParams()
    const articleId = searchParams.get('id')
    //获取实例form对象
    const [form] = Form.useForm()
    console.log(articleId)
    useEffect(()=>{
        //1.通过id获得文章详情
        async function getArticleDetail(){
           const res = await getArticleById(articleId)
            form.setFieldsValue({
             ...res.data,
             type:res.data.cover.type
            })
            //上述回填方法无法恢复封面
            //数据结构的问题 set方法 -> {type：3}  {cover：{type：3}}

            //回填类型
            setImageType(res.data.cover.type)
            //回显图片 （url -> url）
            setImageList(res.data.cover.images.map(url =>{
                return {url}
            }))
        }
        //只有存在文章ID的时候才能回填数据进行编辑,没有ID则表明新发布
        if(articleId){
            getArticleDetail()
        }

        //2.调用实例方法 完成回填数据
    },[articleId,form])


    return (
        <div className="publish">
            <Card
                title={
                    <Breadcrumb items={[
                        { title: <Link to={'/'}>首页</Link> },
                        { title: `${articleId ? '编辑' : '发布'}文章` },
                    ]}
                    />
                }
            >
                <Form
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 16 }}
                    initialValues={{ type: 1 }}
                    onFinish={onFinish}
                    form={form}
                >
                    <Form.Item
                        label="标题"
                        name="title"
                        rules={[{ required: true, message: '请输入文章标题' }]}
                    >
                        <Input placeholder="请输入文章标题" style={{ width: 400 }}  />
                    </Form.Item>
                    <Form.Item
                        label="频道"
                        name="channel_id"
                        rules={[{ required: true, message: '请选择文章频道' }]}
                    >
                        <Select placeholder="请选择文章频道" style={{ width: 400 }} >
                            {/*value属性  用户选中之后会自动收集起来作为接口的提交字段*/}
                            {channelList.map(item => <Option key={item.id} value={item.id}>{item.name}</Option>)}
                        </Select>
                    </Form.Item>
                    <Form.Item label="封面">
                        <Form.Item name="type">
                            <Radio.Group onChange={onTypeChange}>
                                <Radio value={1}>单图</Radio>
                                <Radio value={3}>三图</Radio>
                                <Radio value={0}>无图</Radio>
                            </Radio.Group>
                        </Form.Item>

                        {/*
                        listType：决定选择文件框的外观样式
                        showUploadList：控制显示上传列表
                        */}
                        {imageType > 0 && <Upload
                            listType="picture-card"
                            showUploadList
                            action={'http://geek.itheima.net/v1_0/upload'}
                            name='image'
                            maxCount={imageType}
                            onChange={onChange}
                            beforeUpload={beforeUpload}
                            fileList={imageList}
                        >
                            <div style={{ marginTop: 8 }}>
                                <PlusOutlined />
                            </div>
                        </Upload>}

                    </Form.Item>
                    <Form.Item
                        label="内容"
                        name="content"
                        rules={[{ required: true, message: '请输入文章内容' }]}
                    >
                    {/*富文本编辑器*/}
                        <ReactQuill
                            className="publish-quill"
                            theme="snow"
                            placeholder="请输入文章内容"
                        />
                    </Form.Item>

                    <Form.Item wrapperCol={{ offset: 4 }}>
                        <Space>
                            <Button size="large" type="primary" htmlType="submit">
                                发布文章
                            </Button>
                        </Space>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    )
}

export default Publish