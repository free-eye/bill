//柱状图组件

//1.把功能代码都放到这个组件中
//2.可变的部分抽象成props参数

import {useEffect, useRef} from "react";
import * as echarts from "echarts";

const BarChart = ({title,xAxis,series}) => {
    const chartRef = useRef(null)
    useEffect(() => {
        //保证dom对象可用，再进行图表的渲染
        //1.获取渲染图表的dom节点
        const chartDom = chartRef.current
        //2.图标初始化生成图表实例对象
        const myChart = echarts.init(chartDom);
        //3.准备图表参数
        const option = {
            title:{
                text:title
            },
            xAxis: {
                type: 'category',
                data: xAxis.data
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    data: series.data,
                    type: 'bar'
                }
            ]
        };
        //4.进行图表参数完成图表的渲染
        option && myChart.setOption(option);

    },  [title, xAxis, series]);
    return    <div ref={chartRef} style={{width:'500px',height:'400px'}}></div>
}

export default BarChart