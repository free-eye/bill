import * as echarts from 'echarts';
import {useEffect, useRef} from "react";
import BarChart from "@/pages/Home/components/BarChart";


const Home = () => {

    return (
    <div>
        <BarChart title={'三大前端框架满意度'}
                  xAxis={{
                      data: ['Vue', 'React', 'Angular'] // 这里是xAxis的数据
                  }}
                  series={
                      {
                          data: [100, 200, 150] // 这里是series的数据
                      }
                  }
        />
        <BarChart title={'三大前端框架使用度'}
                  xAxis={{
                      data: ['Vue', 'React', 'Angular'] // 这里是xAxis的数据
                  }}
                  series={
                      {
                          data: [70, 100, 50] // 这里是series的数据
                      }
                  }
        />
    </div>
    )
}

export default Home