import { Button } from 'antd';
function App() {
  return (
    <div>
      this is App
        <Button type="primary">test</Button>
    </div>
  );
}

export default App;
