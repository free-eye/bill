const Board = () => {
  return <div>我是面板</div>
}

export default Board