const NotFound = () => {
  return <div>页面跑到月球了</div>
}

export default NotFound