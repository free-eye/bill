## 1.navigate('/acticle?id=1001&name=zhangsan')とuseSearchParams()
### navigate('/acticle?id=1001&name=zhangsan') 「？」以後の内容は、パラメータの内容で、複数の場合、「＆」で繋がる。
### useSearchParams()で、上記のパラメータの値をとることができ、一つの配列にストレージする。
```javaScript
const [params] = useSearchParams()
let id = params.get('id')
```

## 2.navigate('/acticle/1001/zhangsan')とuseParams()
### navigate('/acticle?id=1001&name=zhangsan') 「？」以後の内容は、パラメータの内容で、複数の場合、「＆」で繋がる。
### useSearchParams()で、上記のパラメータの値をとることができ、一つのオブジェクトにストレージする。
この方法でパラメータの項目をrouterファイルの「path」でセット要。
```javaScript
path: '/article/:id/:name' 
element:<Article />
```
```javaScript
const params = useParams()
let id = params.id
let name = params.name
```
## 3.props でデータの伝送
### 親コンポーネントの設定
```js
import React from 'react';
import ChildComponent from './ChildComponent';

const ParentComponent = () => {
  const user = {
    name: 'Alice',
    age: 25,
    contact: {
      email: 'alice@example.com',
      phone: '123456789'
    }
  };

  return <ChildComponent user={user} />;
};
```
### 子コンポーネントの受け取り
```js
import React from 'react';

const ChildComponent = ({ user }) => {
  const { contact: { email } } = user;

  return <div>Email: {email}</div>;
};

export default ChildComponent;

```
## 4.useCotext()を通して、複数コンポーネント間のデータ伝送
### index.jsでは、createContext（）を使用して、データ伝送用のオブジェクトを作って、輸出する。
![Alt text](image-12.png)

### 「RouterProvider」と共に使用の場合、パスの有効利用を図るため、index.jsでは、Providerコンポーネントを使用して、データを伝送する。
![Alt text](image-13.png)
### 適用されたコンポーネントでは、useContext()でデータを受け取って使用する。
![Alt text](image-14.png)

## 5.嵌套路由（セカンダリルーティング設定）
### routerファイル中の設置
![Alt text](image-1.png)
### layout（初期コンポーネント）には、セカンダリコンポーネントの輸出場所をセット
![Alt text](image-2.png)
### 默认二级路由（デフォルトセカンダリルーティング）のindex設定
![Alt text](image-3.png)
### 404ページ（コンポーネント）の設定
![Alt text](image-4.png)

## 6.urlの変換（useNavigate())
![Alt text](image-20.png)

## 7.别名路径（エイリアスを使ったパス指定）
![Alt text](image-5.png)
### プロジェクトのルートディレクトリ（根目录）には、「craco.config.js」ファイルを作成し、設定。
![Alt text](image-6.png)
### パッケージ中の起動命令を修正。
![Alt text](image-7.png)

## 8.パス内ファイルの自動提示
### プロジェクトのルートディレクトリ（根目录）には、「jsconfig.json」ファイルを作成し、設定。
![Alt text](image-8.png)

## 9.json-serverでデータMock
### プロジェクトのルートディレクトリ（根目录）には、「server/data.json」でデータを用意する。
![Alt text](image-9.png)
### パッケージ中jsonServerの起動命令を追加
![Alt text](image-10.png)

## 10.antD-mobile(ReactのUIコンポーネントライブラリ)
### プロジェクトのグローバル設定(:root:root)
![Alt text](image-11.png)
### 特定スタイルの設定
![Alt text](image-15.png)

## 11.RTK(Redux Toolkit)状態管理ツール
### srcフォルダには、STOREフォルダを作り、下にindex.jsとモジュールフォルダを作成し、モジュールフォルダには各自項目のSTOREを作る。それに、index.jsファイルには、モジュール内の各自storeを導入する。
**一つの例は、下記の通りとする。**
#### モジュールフォルダには、「billStore.js」を作り、関連内容を入力。
![Alt text](image-16.png)
#### storeフォルダのindex.jsには、上記billStoreをインポートする。
![Alt text](image-17.png)
#### プロジェクトのルートディレクトリ（根目录）内のindex.jsには、上記のstoreをインポート。
![Alt text](image-18.png)
#### 該当されたファイルには、上記のuseEffect()とuseDispatch()を通して、json.serverのAPIからデータを受け取る。
![Alt text](image-19.png)

## 12.useMemo()／データの二次処理　lodash：月単位の統計、日単位の統計
### 配列のfilter条件及びreduce(a,c)の計算統計
![Alt text](image-21.png)
![Alt text](image-22.png)
### 更に日単位の統計
・日単位データの統計
![Alt text](image-24.png)
・コンポーネント及び関数のインポート
![Alt text](image-25.png)
・日単位コンポーネント内のデータ展示
![Alt text](image-26.png)
### 日データのリスト展示
・日データリストの展示状態のセット
![Alt text](image-27.png)
・リスト展示スタイルのセット
![Alt text](image-28.png)
### 各項目アイコンの使用
・Iconコンポーネントの作成及びタイプの連動をセット
![Alt text](image-29.png)
・日データリストへのアイコン使用
![Alt text](image-30.png)

## 13.useEffect（副作用フック）の初期化セット
![Alt text](image-23.png)

