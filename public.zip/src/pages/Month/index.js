import {NavBar,DatePicker} from "antd-mobile";
import './index.css'
import {useEffect, useMemo, useState} from "react";
import classNames from "classnames";
import customParseFormat from 'dayjs/plugin/customParseFormat';
import dayjs from "dayjs";
import {useSelector} from "react-redux";
import _ from 'lodash'
import DailyBill from "@/pages/Month/components/DailyBill";

const Month = () => {
    //月単位のデータ統計
    dayjs.extend(customParseFormat);
    const billList = useSelector(state => state.bill.billList)
    const monthGroup = useMemo(() => {
        return _.groupBy(billList,(item)=> dayjs(item.date,'YYYY-M-D HH:mm:ss').format('YYYY-MM'))
    }, [billList]);
    console.log(monthGroup)
    //控制弹框的打开和关闭
    const [dateVisible,setDateVisible] = useState(false)
    //控制时间显示
    const [currentDate,setCurrentDate] = useState(() => {
        return dayjs(new Date()).format('YYYY-MM')
    })
    //设定当月数据保存数组
    const [currentMonthList,setMonthList] = useState([])
    //使用useMemo(),对当月数据进行汇总计算
    const monthResult = useMemo(()=> {
        //支出  |  收入  |  结余
        const pay = currentMonthList.filter(item => item.type === "pay").reduce((a,c) => a+c.money,0)
        const income = currentMonthList.filter(item => item.type === "income").reduce((a,c) => a+c.money,0)
        return{
            pay,
            income,
            total: pay + income
        }
    },[currentMonthList])
    //初期化的时候把当前月的数据计算并显示
    useEffect(()=>{
        const newDate = dayjs().format('YYYY-MM')
        //边界值控制，只有当月有数据时才设定
        if(monthGroup[newDate]) {
            setMonthList(monthGroup[newDate])
        }
    },[monthGroup])

    //选择月度
    const onConfirm = (date) => {
        setDateVisible(false)
        // console.log(date)
        const formatDate = dayjs(date).format('YYYY-MM')
        //获取选择月对应的数据，并设置到保存数组list
        setMonthList(monthGroup[formatDate]??[])
        setCurrentDate(formatDate)
    }

    //当前月数据按照日其分组
    const dayGroup = useMemo(() => {
        const groupData = _.groupBy(currentMonthList,(item)=> dayjs(item.date,'YYYY-M-D HH:mm:ss').format('YYYY-MM-DD'))
        const keys = Object.keys(groupData)
        return {
            groupData,
            keys
        }
    }, [currentMonthList]);

    return (
        <div className="monthlyBill">
            <NavBar className="nav" backArrow={false}>
                月度データ
            </NavBar>
            <div className="content">
                <div className="header">
                {/*時間変換エリア*/}
                    <div className="date" onClick={()=> setDateVisible(true)}>
                        <span className="text">
                            {/*时间格式与字符串不能直接拼接，要添加空字符*/}
                            {currentDate + ""}月データ
                        </span>
                        <span className={classNames('arrow',!dateVisible && 'expand')}></span>
                    </div>
                    {/*統計エリア*/}
                    <div className="twoLineOverview">
                        <div className="item">
                            <span className="money">{monthResult.pay.toFixed(2)}</span>
                            <span className="type">出金</span>
                        </div>
                        <div className="item">
                            <span className="money">{monthResult.income.toFixed(2)}</span>
                            <span className="type">入金</span>
                        </div>
                        <div className="item">
                            <span className="money">{monthResult.total.toFixed(2)}</span>
                            <span className="type">残金</span>
                        </div>
                    </div>
                {/*タイマーセレクター*/}
                    <DatePicker
                      className = "kaDate"
                      title="記帳日付"
                      precision="month"
                      visible={dateVisible}
                      onCancel={() => setDateVisible(false)}
                      onConfirm={onConfirm}
                      onClose={() => setDateVisible(false)}
                      max={new Date()}
                    />

                </div>
                {/*当日列表组件的追加*/}
                {
                    dayGroup.keys.map(key => {
                        return <DailyBill key={key} date = {key} billList = {dayGroup.groupData[key]} />
                    })
                }
            </div>
        </div>)
}

export default Month