const New = () => {
    return <div>我是new</div>
}

export default New