//bill関連のストア作成
import {createSlice} from "@reduxjs/toolkit";
import axios from "axios";

const billStore =　createSlice({
    //データの状態
    name:'bill',
    initialState:{
        billList:[]
    },
    reducers:{
        //同期改修方法
        setBillList(state,action){
            state.billList = action.payload
        }
    }
})
//actionCreate関数を解析
const {setBillList} = billStore.actions

//非同期の改修方法
const getBillList = () => {
    return async (dispatch) => {
       const res = await axios.get('http://localhost:8888/ka')
        dispatch(setBillList(res.data))
    }
}

export {getBillList}

//reducerを輸出
const reducer = billStore.reducer

export default reducer