const sum = (a,b) => {
    return a + b
}

export default sum
