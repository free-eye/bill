export const billListData　=
{
    pay:[
        {
            type: 'foods',
            name: '餐饮',
            list: [
                {type: 'food', name: '餐费'},
                {type: 'drinks', name: '酒水饮料'}
            ]
        }

    ],
        income:[
        {
            type: 'other',
            name: '其他收入',
            list: [
                {type: 'salary', name: '工资'},
                {type: 'bonus', name: '奖金'}
            ]
        }

    ]
}

export const billTypeToName = Object.keys(billListData).reduce((prev,key)=>{
    billListData[key].forEach(bill => {
        bill.list.forEach(item => {
            prev[item.type] = item.name
        })
    })
    return prev
},{})