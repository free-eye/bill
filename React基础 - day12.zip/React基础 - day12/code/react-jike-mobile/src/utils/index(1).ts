// 模块中转导出文件

import { httpInstance } from './http'

export { httpInstance as http }
