import { Button } from 'antd-mobile'

const App = () => {
  return (
    <div>
      <Button color="success">click me</Button>this is app
    </div>
  )
}

export default App
