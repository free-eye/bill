// 1. 定义泛型

export type ResType<T> = {
  message: string
  data: T
}
